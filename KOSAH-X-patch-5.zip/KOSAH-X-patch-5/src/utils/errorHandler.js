// errorHandler.js — the single entry point for all error handling.
//
// Rules:
// 1. Commands/handlers: throw TitanBotError (via createError) or let errors propagate;
//    interactionCreate routes them through handleInteractionError. For expected user-facing
//    failures (validation, cooldowns), use replyUserError.
//    Do NOT wrap a command's execute() body in a try/catch whose only purpose is to call
//    handleInteractionError — that is redundant because interactionCreate already catches
//    command.execute errors and calls handleInteractionError with COMMAND_ERROR_SUBTYPES.
//    Only keep a local try/catch when the catch does something more (custom recovery,
//    typed re-throw, status-code branching) or when it lives in a standalone handler
//    (collector callbacks, modal/component handlers) not reached via the command path.
// 2. Services: throw, never return { success: false }. Wrap exports with wrapServiceBoundary
//    (re-exported here) so unknown errors get typed with service/operation context.
// 3. Background tasks (cron, timers): wrap with handleTaskError / runSafeTask.
// 4. Set a specific userMessage when you know the cause; use ErrorTypes, don't invent titles.
// 5. Success/info/warning replies use successEmbed / infoEmbed / warningEmbed.

import { logger } from './logger.js';
import { buildUserErrorEmbed } from './embeds.js';
import { MessageFlags } from 'discord.js';
import { getErrorMetadata, getDefaultErrorCodeByType, resolveErrorCode, ErrorCodes } from './errorRegistry.js';
import { InteractionHelper } from './interactionHelper.js';

// Re-export so consumers only ever need to import from errorHandler.js
export { ErrorCodes, getErrorMetadata, resolveErrorCode, getDefaultErrorCodeByType } from './errorRegistry.js';
export { ensureTypedServiceError, wrapServiceBoundary, wrapServiceClassMethods } from './serviceErrorBoundary.js';

export const ErrorTypes = {
    VALIDATION: 'validation',
    PERMISSION: 'permission',
    CONFIGURATION: 'configuration',
    DATABASE: 'database',
    NETWORK: 'network',
    DISCORD_API: 'discord_api',
    USER_INPUT: 'user_input',
    RATE_LIMIT: 'rate_limit',
    UNKNOWN: 'unknown'
};

export class TitanBotError extends Error {
    constructor(message, type = ErrorTypes.UNKNOWN, userMessage = null, context = {}) {
        super(message);
        this.name = 'TitanBotError';
        this.type = type;
        this.userMessage = userMessage;
        this.context = context;
        this.code = context?.errorCode || getDefaultErrorCodeByType(type);
        this.timestamp = new Date().toISOString();
    }
}

// Discord API error codes that indicate a permission problem rather than a bug.
const DISCORD_PERMISSION_CODES = new Set([
    50001, // Missing Access
    50013, // Missing Permissions
    50007, // Cannot send messages to this user (DMs closed)
    160002, // Cannot reply without permission to read message history
]);

// PostgreSQL / node-postgres error codes and errno values that indicate database trouble.
const DATABASE_ERROR_CODES = new Set([
    'ECONNREFUSED', 'ECONNRESET', 'ETIMEDOUT',
    '57014', // query_canceled (statement timeout)
    '53300', // too_many_connections
    '08006', '08001', '08003', // connection failures
    '40001', '40P01', // serialization failure / deadlock
]);

const TECHNICAL_ERROR_PATTERNS = [
    /^typeerror:/i,
    /^referenceerror:/i,
    /^syntaxerror:/i,
    /cannot read propert/i,
    /is not a function/i,
    /is not defined/i,
    /unexpected token/i,
    /econnrefused|enotfound|etimedout|econnreset/i,
    /node_modules/i,
    /\sat\s.+\(.+\:\d+\:\d+\)/,
];

const USER_FACING_ERROR_HINTS = [
    /^please\b/i,
    /^you must\b/i,
    /^provide\b/i,
    /^select\b/i,
    /^choose\b/i,
    /^enter\b/i,
    /^that\b/i,
    /^this\b/i,
    /^unsupported\b/i,
    /^unknown command\b/i,
    /^invalid\b/i,
    /^missing\b/i,
    /^cannot\b/i,
    /^could not find\b/i,
];

function isUserFacingPlainError(error) {
    if (error instanceof TitanBotError) {
        return false;
    }

    const message = typeof error?.message === 'string' ? error.message.trim() : '';
    if (!message || message.length > 500 || message.includes('\n')) {
        return false;
    }

    if (TECHNICAL_ERROR_PATTERNS.some((pattern) => pattern.test(message))) {
        return false;
    }

    const lowerMessage = message.toLowerCase();
    if (USER_FACING_ERROR_HINTS.some((pattern) => pattern.test(message))) {
        return true;
    }

    if (lowerMessage.includes('not found')
        || lowerMessage.includes('not configured')
        || lowerMessage.includes('not set up')
        || lowerMessage.includes('not available')
        || lowerMessage.includes('permission')
        || lowerMessage.includes('must be ')
        || lowerMessage.includes('at least ')
        || lowerMessage.includes('no longer than ')
        || lowerMessage.includes('at most ')) {
        return true;
    }

    return false;
}

function inferErrorTypeFromUserMessage(message = '') {
    const lowerMessage = message.toLowerCase();

    if (lowerMessage.includes('permission') || lowerMessage.includes('not allowed')) {
        return ErrorTypes.PERMISSION;
    }

    if (lowerMessage.includes('rate limit') || lowerMessage.includes('cooldown') || lowerMessage.includes('too quickly')) {
        return ErrorTypes.RATE_LIMIT;
    }

    if (lowerMessage.includes('database') || lowerMessage.includes('postgres') || lowerMessage.includes('sql')) {
        return ErrorTypes.DATABASE;
    }

    if (lowerMessage.includes('not found')
        || lowerMessage.includes('not configured')
        || lowerMessage.includes('not set up')
        || lowerMessage.includes('disabled')
        || lowerMessage.includes('unknown command')
        || lowerMessage.includes('unknown category')) {
        return ErrorTypes.CONFIGURATION;
    }

    if (lowerMessage.includes('channel') || lowerMessage.includes('user') || lowerMessage.includes('role') || lowerMessage.includes('mention')) {
        return ErrorTypes.USER_INPUT;
    }

    return ErrorTypes.VALIDATION;
}

function normalizeInteractionError(error, context = {}) {
    if (error instanceof TitanBotError) {
        return error;
    }

    if (!isUserFacingPlainError(error)) {
        return error;
    }

    const message = error.message.trim();
    const type = inferErrorTypeFromUserMessage(message);

    return createError(message, type, message, {
        ...context,
        expected: true,
        source: context.source || 'normalizeInteractionError',
    });
}

export function categorizeError(error) {
    if (error instanceof TitanBotError) {
        return error.type;
    }

    const message = error?.message?.toLowerCase() || '';
    const code = error?.code;

    if (typeof code === 'string' && DATABASE_ERROR_CODES.has(code)) {
        return ErrorTypes.DATABASE;
    }

    if (message.includes('rate limit') || code === 429) {
        return ErrorTypes.RATE_LIMIT;
    }

    if (DISCORD_PERMISSION_CODES.has(code)) {
        return ErrorTypes.PERMISSION;
    }

    // Remaining numeric codes in Discord's ranges (unknown entity 10xxx, request-level 5xxxx, etc.)
    if (typeof code === 'number' && code >= 10000) {
        return ErrorTypes.DISCORD_API;
    }

    if (error?.name === 'AbortError' || message.includes('network') || message.includes('fetch failed') || message.includes('enotconn')) {
        return ErrorTypes.NETWORK;
    }

    if (message.includes('permission') || message.includes('missing access') || message.includes('missing permissions')) {
        return ErrorTypes.PERMISSION;
    }

    if (message.includes('database') || message.includes('postgres') || message.includes('sql') || message.includes('connection') || message.includes('timeout')) {
        return ErrorTypes.DATABASE;
    }

    if (message.includes('validation') || message.includes('invalid') || message.includes('required')) {
        return ErrorTypes.VALIDATION;
    }

    if (message.includes('config') || message.includes('not found')) {
        return ErrorTypes.CONFIGURATION;
    }

    if (isUserFacingPlainError(error)) {
        return inferErrorTypeFromUserMessage(error.message);
    }

    if (error?.name === 'DiscordAPIError' || error?.name === 'HTTPError') {
        return ErrorTypes.DISCORD_API;
    }

    return ErrorTypes.UNKNOWN;
}

const UserMessages = {
    [ErrorTypes.VALIDATION]: {
        default: 'Please check your input and try again.',
        missing_required: "You're missing some required information. Check the command options and try again.",
        invalid_format: 'The format you provided is incorrect. Check the command usage and try again.'
    },
    [ErrorTypes.PERMISSION]: {
        default: "You don't have permission to do that.",
        user_permission: "You don't have permission to use this command.",
        bot_permission: "I don't have the permissions needed to do that in this channel."
    },
    [ErrorTypes.CONFIGURATION]: {
        default: 'This feature is not set up yet. Ask a server administrator to configure it.',
        missing_config: 'This feature has not been configured yet. Ask a server administrator to set it up.',
        invalid_config: 'The server configuration for this feature is invalid. Ask a server administrator to review it.'
    },
    [ErrorTypes.DATABASE]: {
        default: 'Something went wrong while saving data. Please try again in a moment.',
        connection_failed: 'I could not reach the database. Please try again later.',
        timeout: 'That took too long to complete. Please try again.'
    },
    [ErrorTypes.NETWORK]: {
        default: 'I could not reach an external service. Please try again in a moment.',
        timeout: 'The request timed out. Please try again.',
        unreachable: 'The service is unavailable right now. Please try again later.'
    },
    [ErrorTypes.DISCORD_API]: {
        default: 'Discord rejected that request. Please try again in a moment.',
        rate_limit: "You're doing that too quickly. Wait a moment and try again.",
        forbidden: "I'm not allowed to do that here. Check my role permissions.",
        interaction_expired: 'That interaction expired. Please run the command again.',
        already_acknowledged: 'That action was already handled. Run the command again if you still need help.',
        invalid_form_body: 'Discord rejected the request payload. Try again with different input.'
    },
    [ErrorTypes.USER_INPUT]: {
        default: 'There was a problem with your request. Check your input and try again.',
        invalid_user: 'I could not find that user. Check the mention or ID and try again.',
        invalid_channel: 'I could not find that channel. Check the mention or ID and try again.'
    },
    [ErrorTypes.RATE_LIMIT]: {
        default: "You're doing that too quickly. Wait a moment and try again.",
        command_cooldown: 'This command is on cooldown. Wait before using it again.',
        global_rate_limit: 'Discord is rate limiting requests. Wait a moment and try again.'
    },
    [ErrorTypes.UNKNOWN]: {
        default: 'Something went wrong. Please try again in a moment.',
        unexpected: 'An unexpected error occurred. Please try again later.',
        warn_failed: 'I could not warn that member. Check my permissions and role hierarchy, then try again.',
        kick_failed: 'I could not kick that member. Check my permissions and role hierarchy, then try again.',
        ban_failed: 'I could not ban that member. Check my permissions and role hierarchy, then try again.',
        unban_failed: 'I could not unban that user. Check my permissions and try again.',
        timeout_failed: 'I could not timeout that member. Check my permissions and role hierarchy, then try again.',
        untimeout_failed: 'I could not remove the timeout. Check my permissions and try again.'
    }
};

export function getUserMessage(error, context = {}) {
    const type = categorizeError(error);
    const messages = UserMessages[type] || UserMessages[ErrorTypes.UNKNOWN];

    if (error.userMessage) {
        return error.userMessage;
    }

    if (isUserFacingPlainError(error)) {
        return error.message.trim();
    }

    if (type === ErrorTypes.DISCORD_API) {
        if (error?.code === 10062) {
            return messages.interaction_expired;
        }
        if (error?.code === 40060 || error?.code === 50027) {
            return messages.already_acknowledged;
        }
        if (error?.code === 50035) {
            return messages.invalid_form_body;
        }
    }

    if (context.subtype && messages[context.subtype]) {
        return messages[context.subtype];
    }

    if (context.subtype && UserMessages[ErrorTypes.UNKNOWN][context.subtype]) {
        return UserMessages[ErrorTypes.UNKNOWN][context.subtype];
    }

    return messages.default;
}

function buildErrorLogData(interaction, error, errorType, context = {}) {
    const resolvedErrorCode = resolveErrorCode({ error, errorType, context });
    const errorMetadata = getErrorMetadata(resolvedErrorCode);
    const traceId = context.traceId || interaction?.traceContext?.traceId || interaction?.traceId || error?.context?.traceId;

    return {
        logData: {
            event: 'interaction.error',
            errorCode: resolvedErrorCode,
            remediationHint: errorMetadata.remediation,
            severity: errorMetadata.severity,
            retryable: errorMetadata.retryable,
            error: error.message,
            type: errorType,
            traceId,
            guildId: interaction?.guildId,
            userId: interaction?.user?.id,
            command: interaction?.commandName || context.command,
            interaction: interaction ? {
                type: interaction.type,
                commandName: interaction.commandName,
                customId: interaction.customId,
                userId: interaction.user?.id,
                guildId: interaction.guildId,
                channelId: interaction.channelId
            } : undefined,
            context
        },
        traceId,
        resolvedErrorCode,
        errorMetadata
    };
}

function logInteractionError(error, errorType, logData) {
    const isUserError = USER_ERROR_TYPES.has(errorType);
    const isExpectedError = Boolean(error?.context?.expected === true || error?.context?.suppressErrorLog === true);

    if (isUserError || isExpectedError) {
        if (errorType !== ErrorTypes.RATE_LIMIT) {
            logger.debug(`User Error [${errorType.toUpperCase()}]: ${error.userMessage || error.message}`, logData);
        }
    } else {
        logger.error(`System Error [${errorType.toUpperCase()}]`, {
            ...logData,
            stack: error.stack
        });
    }
}

async function sendErrorResponse(interaction, embed, context = {}) {
    try {
        if (!interaction || !interaction.id) {
            logger.warn('Interaction was null or invalid when handling error', {
                event: 'interaction.error.invalid_interaction',
                errorCode: ErrorCodes.INTERACTION_INVALID,
                remediationHint: getErrorMetadata(ErrorCodes.INTERACTION_INVALID).remediation,
                traceId: context.traceId
            });
            return false;
        }

        const coordinator = InteractionHelper.getCoordinator(interaction);
        if (coordinator?.isUsageFinalized()) {
            return false;
        }

        if (interaction.createdTimestamp && (Date.now() - interaction.createdTimestamp) > 14 * 60 * 1000) {
            logger.warn('Interaction expired before error handler could send response', {
                event: 'interaction.error.expired',
                errorCode: ErrorCodes.INTERACTION_EXPIRED,
                remediationHint: getErrorMetadata(ErrorCodes.INTERACTION_EXPIRED).remediation,
                traceId: context.traceId,
                guildId: interaction.guildId,
                userId: interaction.user?.id,
                command: interaction.commandName || context.command
            });
            return false;
        }

        const errorMessage = { embeds: [embed] };

        if (interaction._isPrefixCommand) {
            if (coordinator?.hasResponded()) {
                await coordinator.edit(errorMessage);
            } else {
                await coordinator?.respond(errorMessage);
            }
            return true;
        }

        const useEphemeral = context.ephemeral !== false;

        if (interaction.replied) {
            // A visible reply already exists; don't overwrite it — follow up ephemerally.
            await interaction.followUp({ ...errorMessage, flags: MessageFlags.Ephemeral });
        } else if (interaction.deferred) {
            await interaction.editReply(errorMessage);
        } else {
            if (useEphemeral) {
                errorMessage.flags = MessageFlags.Ephemeral;
            }
            await interaction.reply(errorMessage);
        }

        return true;
    } catch (replyError) {
        if (replyError.code === 40060 || replyError.code === 10062 || replyError.code === 50027) {
            logger.warn('Interaction already acknowledged, expired, or token invalid; cannot send error response:', {
                event: 'interaction.error.response_unavailable',
                errorCode: String(replyError.code),
                traceId: context.traceId,
                guildId: interaction.guildId,
                userId: interaction.user?.id,
                command: interaction.commandName || context.command,
                code: replyError.code
            });
            return false;
        }

        logger.error('Failed to send error response:', {
            event: 'interaction.error.response_failed',
            errorCode: String(replyError.code || ErrorCodes.INTERACTION_RESPONSE_FAILED),
            remediationHint: getErrorMetadata(ErrorCodes.INTERACTION_RESPONSE_FAILED).remediation,
            traceId: context.traceId,
            guildId: interaction.guildId,
            userId: interaction.user?.id,
            command: interaction.commandName || context.command,
            error: replyError
        });
        return false;
    }
}

/**
 * Reply with a typed user-facing error (early-return validation, permission checks, etc.).
 */
export async function replyUserError(interaction, {
    type = ErrorTypes.UNKNOWN,
    message,
    subtype = null,
    ephemeral = true,
    context = {}
} = {}) {
    const errorType = type || ErrorTypes.UNKNOWN;
    const syntheticError = message
        ? createError('User error', errorType, message, { expected: true, ...context })
        : createError('User error', errorType, null, { expected: true, ...context });

    const userMessage = getUserMessage(syntheticError, { subtype, ...context });
    const { logData, traceId } = buildErrorLogData(interaction, syntheticError, errorType, {
        ...context,
        subtype,
        source: context.source || 'replyUserError'
    });

    logInteractionError(syntheticError, errorType, logData);

    const embed = buildUserErrorEmbed(errorType, userMessage);
    return sendErrorResponse(interaction, embed, { ...context, traceId, ephemeral, subtype });
}

const USER_ERROR_TYPES = new Set([
    ErrorTypes.VALIDATION,
    ErrorTypes.RATE_LIMIT,
    ErrorTypes.USER_INPUT,
    ErrorTypes.PERMISSION,
    ErrorTypes.CONFIGURATION,
]);

function buildErrorReference(resolvedErrorCode, traceId) {
    const shortTrace = traceId ? String(traceId).slice(0, 8) : null;
    return shortTrace ? `${resolvedErrorCode} · ${shortTrace}` : resolvedErrorCode;
}

export async function handleInteractionError(interaction, error, context = {}) {
    const normalizedError = normalizeInteractionError(error, context);
    const errorType = categorizeError(normalizedError);
    const userMessage = getUserMessage(normalizedError, context);
    const { logData, traceId, resolvedErrorCode } = buildErrorLogData(interaction, normalizedError, errorType, context);

    logInteractionError(normalizedError, errorType, logData);

    // System errors get a reference code so users can report them and we can grep logs.
    const isUserError = USER_ERROR_TYPES.has(errorType) || normalizedError?.context?.expected === true;
    const description = isUserError
        ? userMessage
        : `${userMessage}\n\n-# Ref: \`${buildErrorReference(resolvedErrorCode, traceId)}\``;

    const embed = buildUserErrorEmbed(errorType, description);
    await sendErrorResponse(interaction, embed, { ...context, traceId });
}

/**
 * Central error handler for non-interaction contexts (cron jobs, timers, event
 * side-effects). Logs with the same structured fields as interaction errors.
 */
export function handleTaskError(taskName, error, context = {}) {
    const errorType = categorizeError(error);
    const resolvedErrorCode = resolveErrorCode({ error, errorType, context });
    const errorMetadata = getErrorMetadata(resolvedErrorCode);

    logger.error(`Task Error [${taskName}] [${errorType.toUpperCase()}]`, {
        event: 'task.error',
        task: taskName,
        errorCode: resolvedErrorCode || ErrorCodes.TASK_ERROR,
        remediationHint: errorMetadata.remediation,
        severity: errorMetadata.severity,
        retryable: errorMetadata.retryable,
        type: errorType,
        error: error?.message || String(error),
        stack: error?.stack,
        context
    });
}

/**
 * Wrap a background task so it can never produce an unhandled rejection.
 * Usage: cron.schedule('* * * * *', runSafeTask('giveaways', () => checkGiveaways(client)))
 */
export function runSafeTask(taskName, fn, context = {}) {
    return async (...args) => {
        try {
            return await fn(...args);
        } catch (error) {
            handleTaskError(taskName, error, context);
            return null;
        }
    };
}

export function withErrorHandling(fn, context = {}) {
    return async (...args) => {
        try {
            return await fn(...args);
        } catch (error) {
            const interaction = args.find((arg) =>
                arg && typeof arg === 'object' &&
                (arg.isCommand || arg.isButton || arg.isModalSubmit || arg.isStringSelectMenu || arg.isChatInputCommand || arg._isPrefixCommand)
            );

            // Slash commands are handled by interactionCreate — re-throw so the
            // central handler can attach trace context and command subtypes.
            if (interaction?.isChatInputCommand?.()) {
                throw error;
            }

            if (interaction) {
                await handleInteractionError(interaction, error, context);
            } else {
                logger.error('Error in non-interaction context:', error);
            }

            return null;
        }
    };
}

export function createError(message, type = ErrorTypes.UNKNOWN, userMessage = null, context = {}) {
    const normalizedContext = {
        ...context,
        errorCode: context?.errorCode || getDefaultErrorCodeByType(type)
    };

    return new TitanBotError(message, type, userMessage, normalizedContext);
}

export default {
    ErrorTypes,
    TitanBotError,
    categorizeError,
    getUserMessage,
    replyUserError,
    handleInteractionError,
    handleTaskError,
    runSafeTask,
    withErrorHandling,
    createError
};
